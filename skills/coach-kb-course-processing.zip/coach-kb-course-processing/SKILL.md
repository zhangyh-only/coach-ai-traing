---
name: coach-kb-course-processing
description: Use when processing Coach course materials into AI sparring knowledge-base artifacts, especially requests involving /Users/zhangyh/code/coach-陪练, 课程资料, Coach陪练知识库, course analysis notes, KB1-KB5 documents, SCORM zip/html courses, PDF/PPT/PPTX/DOCX/video resources, GenZ customer personas, TA Card methods, or Coach product/service training.
---

# Coach KB Course Processing

## Core Principle

Process Coach course materials as the fact source for the AI sparring KB. New scenario files, customer persona files, and business-teacher notes are anchors for priority, scene shape, and persona enrichment; they do not replace course facts.

Use this skill together with `ai-sparring-kb-builder` when the task is about KB architecture or KB document generation.

## Hard Rules

- Do not create Codex automations unless the user explicitly asks for an automation. Default to one user-initiated batch in the current thread.
- Do not create a local pipeline project unless the user asks for tooling. It is OK to create output artifacts such as `output/course_analysis`, `output/kb`, and `output/review`.
- Do not generate final KB directly from new-scenario files or persona images. First extract course content, then generate KB.
- Treat each usable course as a full KB1-KB5 source. The course analysis must inspect all usable content and state how it contributes to KB1, KB2, KB3, KB4, and KB5, even when some libraries have no confirmed content.
- Do not reduce a course to a single high-level summary. If a course contains product, service, method, persona/objection, and evaluation cues, preserve each cue in the analysis and route it to the appropriate KB layer.
- Formal KB outputs may update one or several existing KB documents when the course contains independently retrievable knowledge for multiple libraries. Avoid needless duplicate files, but do not suppress KB4 or KB5 content just because another KB is the strongest fit.
- Do not wait for dedicated persona files before generating KB4. Course facts about buying motives, usage scenarios, product-fit audiences, objections, latent concerns, social-media preferences, service anxieties, and "what pushes the customer away" are valid KB4 sources when traceable.
- Prefer updating an existing KB over creating a duplicate. Many courses may accumulate into the same KB document when they teach the same retrieval unit.
- Do not invent product specs, prices, service rules, method definitions, or wording. Missing or conflicting facts go into `待确认事项`.
- Keep Coach terminology unchanged: `Expressive Luxury`, `TA Card`, `E.N.D.`, `A.L.L.`, `A.A.A.`, `价格三明治`, `Retail`, `Outlet`, `CR`, `AT CR`.
- Use `顾客`, not `客户`, for Coach role-play unless quoting source text.

## Expected Workspace

Default project root:
`/Users/zhangyh/code/coach-陪练`

Prefer the newest local anchors if present:

- `Coach陪练知识库架构设计_v1_4.md`
- `Coach知识库文档生成Prompt模板_v1_2.md`
- `Coach培训资料内容分析提示词.md`
- Course source directory: `课程资料/`
- Scenario/persona directory: `新场景要求及辅助资料整理/`

If any anchor is missing, find the nearest newer version before proceeding. If no equivalent exists, ask the user for the path.

## Execution Flow

1. **Select a small batch**
   - Process 1-3 course folders per user request unless the user asks for a larger batch.
   - Start with high-value source groups: brand, product/material, TA Card, GenZ communication, service/transaction, seasonal themes.

2. **Extract course content**
   - PDF: extract text with page references; render/inspect pages when extraction is sparse.
   - PPT/PPTX: extract slide text, speaker notes if available, tables, visible captions, and image captions when meaningful.
   - DOC/DOCX: extract paragraphs and tables.
   - SCORM zip/html: unzip to a temp/output extraction folder, inspect manifest/index HTML, and extract visible lesson text, quiz text, answers, captions, and embedded JSON strings when relevant.
   - Video: use existing subtitles/transcripts if present. If none exist, mark as `待转写/待人工提供转写`, do not guess.
   - Keep source trace: file name + page/slide/html path/section.

3. **Create course analysis notes**
   - Use `Coach培训资料内容分析提示词.md`.
   - Save one note per course under `output/course_analysis/`.
   - Required sections: source metadata, page/slide/unit-level extraction, extracted product/service/method/persona/evaluation facts, original wording, numeric facts, Coach terms, and `待补信息与归属疑点`.
   - Mark `来源角色` as `课程事实来源`, `新场景需求来源`, or `画像补充来源`.
   - Include a `KB1-KB5 覆盖矩阵` for every usable course:
     - KB1: brand/channel/service/transaction/communication facts
     - KB2: product/material/category/theme/SKU facts
     - KB3: sales flow, method, scenario action, talk track facts
     - KB4: behavior persona, objection, latent concern, decision anxiety, buying motive, role-play cues, "pushed away by" cues
     - KB5: observable evaluation points, scoring evidence, mistakes to flag, pass/fail criteria inferable from the course
   - Choose a primary update target only for batch tracking, not as a reason to discard other KB-layer content.

4. **Map notes to KB documents**
   - Use `Coach陪练知识库架构设计_v1_4.md` to decide target KB docs.
   - Use scenario/persona files only for mapping priority and persona enrichment.
   - Treat mapping as course -> KB1-KB5 contribution set. For each confirmed contribution, decide whether the target KB document already exists:
     - If it exists, update that KB with clear source attribution and version/date changes.
     - If it does not exist, create one new KB document using the architecture's naming and granularity.
   - Many courses may map into the same KB when they teach the same retrieval unit, such as `KB2-正价-皮革与材质知识` or `KB3-方法-TA Card销售技巧总览`.
   - Do not create duplicate KB documents for the same retrieval unit. However, when a course truly teaches separate reusable content for multiple libraries, update each relevant KB rather than forcing all facts into one document.
   - Typical primary target mapping:
     - Brand/service/channel facts -> KB1
     - Product, material, series, Retail/Outlet differences -> KB2
     - Six-stage flow, TA Card, E.N.D./A.L.L./A.A.A./price sandwich -> KB3
     - Four behavior personas, objections, latent concerns, buying motives, decision anxieties, role-play reactions -> KB4
     - Evaluation cues, scoring evidence, observable learner behaviors, common mistakes, pass/fail criteria -> KB5. A dedicated external evaluation standard is not required; course training objectives and "do/don't", quiz, scenario, and method requirements are valid KB5 sources when clearly traceable.

5. **Generate or update KB docs**
   - Use `Coach知识库文档生成Prompt模板_v1_2.md`.
   - Save final KB files under `output/kb/`.
   - Produce all KB artifacts justified by the course's confirmed KB1-KB5 contributions. Track the dominant target in the review summary, but do not treat it as exclusive.
   - Before creating a new KB, search existing `output/kb/` files and prior generated KB drafts for the same retrieval unit.
   - When several course notes contribute to the same KB, merge them into that KB with clear source attribution instead of creating duplicate KB files.
   - If a course has only a title page, corrupt file, missing transcript, or otherwise no usable course content, do not invent a KB body. Create the course analysis note and review summary with the blocked primary KB target and required source gap.
   - Include `数据来源` with original course files, not only intermediate-note names.
   - Include `待确认事项` when course facts conflict with scenario notes or are incomplete.

6. **Review before final**
   - Check old pitfalls:
     - A/B persona treated as KB4 main category
     - Xlsx used as fact source for product/method/service facts
     - Complete dialogue lines used as objection labels
     - Missing numeric facts, prices, service durations, return periods
     - Coach terms translated or generalized
   - Summarize generated files and unresolved questions.

## Source Priority

| Source | Role | Allowed Use |
|--------|------|-------------|
| Course materials | Fact source | Brand, product, materials, service rules, return policy, TA Card methods, GenZ principles, wording |
| Business-teacher scenario files | Scene anchor | Six-stage flow, four behavior types, objection structure, role-play priorities |
| China Persona / role images | Persona supplement | Age, city, income, channel preference, social dependency, return tendency |
| Existing KB drafts | Reference only | Check consistency; do not treat as source of truth over courses |

If sources conflict, keep course facts in the KB body and list the conflict in `待确认事项`.

## Batch Output Shape

Recommended per run:

```text
output/
  course_analysis/
    [course-id]-[short-name].md
  kb/
    KB1-...
    KB2-...
    KB3-...
    KB4-...
  review/
    [date]-batch-summary.md
```

The batch summary should list processed course folders, generated/updated files, source gaps, and recommended next batch.

## Course-To-KB Coverage

Default rule: one course -> full KB1-KB5 coverage analysis, then one or more justified KB updates.

| Course state | Required outcome |
|--------------|------------------|
| New retrieval unit not covered by existing KB | Create one new KB document for that retrieval unit |
| Same retrieval unit already exists | Update that existing KB document |
| Course contains confirmed facts for multiple KB layers | Update each relevant KB layer, or at minimum record the exact contribution in the KB1-KB5 coverage matrix if the formal KB document is intentionally deferred |
| Course contains side mentions too thin for formal KB | Keep side mentions in the course analysis as related KB clues and explain why they are too thin |
| Source has no usable lesson content | Do not invent KB body; record blocked primary KB target and source gap |

Never let a "primary target" hide secondary KB4/KB5 content. When in doubt, preserve the extracted detail in the course analysis and mark the formal KB action as `待确认/待补源`, rather than dropping it.

## Course Group Priority

1. Brand and purpose: `Expressive Luxury`, `在店铺中践行品牌宗旨`
2. Product and material: `Tabby`, `Juliet`, `皮革知识`, `皮革描述词`, Retail/Outlet product courses
3. TA Card methods: `E.N.D.`, `A.L.L.`, `A.A.A.`, `价格三明治`
4. GenZ communication: `Gen-Z精神指南`, `与Z同频`, `小红书热点`, `Gen Z Community`
5. Service/transaction: `顾客体验 - 介绍侧重点和参考话术`, `退换货流程`
6. Seasonal themes and accessories: Retail/Outlet monthly themes, trend reports, charms, newness

## Common Mistakes

| Mistake | Fix |
|---------|-----|
| Starting from KB4/persona files because role-play is the business focus | Start from course extraction; use persona files only after course facts are available |
| Waiting for persona files before writing KB4 | Use course-derived customer motives, objections, concerns, and reaction cues to update KB4; persona files enrich but are not a prerequisite |
| Building a local automation/project | Do the requested batch in the current thread unless the user explicitly asks for tooling |
| Treating SCORM zip as opaque | Unzip and inspect HTML/manifest/assets for visible lesson content |
| Using full scripted customer lines as objections | Convert to `关切主题 + 潜台词/心理倾向`; keep original lines only as source notes |
| Blending Retail and Outlet selling logic | Keep channel attribute explicit and note when a fact is channel-specific |
| Forcing one course into only one KB doc | First build the KB1-KB5 coverage matrix; update every KB layer with confirmed reusable content, while avoiding duplicate files for the same retrieval unit |
| Creating a duplicate KB when the target already exists | Update the existing KB and append the course source attribution |
